function wish() {
	
  var ans=confirm("Do you want to see your favorite list?");
  
  if(ans == true){
	 location.replace("wishList.html");
	 
  }

	  
}